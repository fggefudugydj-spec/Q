package com.example.engine

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.core.content.pm.PackageInfoCompat
import com.example.core.LeviLogger
import com.example.model.ExternalApkInspection
import com.example.model.InstalledMinecraftPackage
import com.example.model.MinecraftEdition
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.ZipFile

object MinecraftPackageDiscovery {

    const val TARGET_VERSION_NAME = "1.26.70.24"
    const val PREVIEW_PACKAGE_NAME = "com.mojang.minecraftpe.preview"
    const val RELEASE_PACKAGE_NAME = "com.mojang.minecraftpe"
    const val TRIAL_PACKAGE_NAME = "com.mojang.minecrafttrialpe"
    const val BETA_PACKAGE_NAME = "com.mojang.minecraftpe.beta"

    private val TARGET_VERSION_REGEX = Regex("""(?:^|[^0-9])1\.26\.70\.24(?:$|[^0-9])""")

    val CANDIDATE_PACKAGES = listOf(
        PREVIEW_PACKAGE_NAME,
        RELEASE_PACKAGE_NAME,
        TRIAL_PACKAGE_NAME,
        BETA_PACKAGE_NAME
    )

    fun discoverInstalledPackages(
        context: Context,
        logger: LeviLogger? = null
    ): List<InstalledMinecraftPackage> {
        val pm = context.packageManager
        val found = mutableListOf<InstalledMinecraftPackage>()

        val discoveredNames = linkedSetOf<String>().apply {
            addAll(CANDIDATE_PACKAGES)
            addAll(queryMinecraftLauncherPackages(pm))
        }

        logger?.info(
            "STAGE_A",
            "Scanning installed Minecraft packages (${discoveredNames.size} candidate(s)): ${discoveredNames.joinToString(", ")}"
        )

        val deviceAbis = Build.SUPPORTED_ABIS?.toList().orEmpty()
        val deviceHasArm64 = "arm64-v8a" in deviceAbis

        for (pkg in discoveredNames) {
            val info = getPackageInfoCompat(pm, pkg)
            if (info != null) {
                val appInfo = info.applicationInfo
                val versionName = info.versionName?.trim().orEmpty().ifBlank { "unknown" }
                val versionCode = PackageInfoCompat.getLongVersionCode(info)
                val appLabel = appInfo?.loadLabel(pm)?.toString() ?: pkg
                val sourceDir = appInfo?.sourceDir ?: ""
                val splits = appInfo?.splitSourceDirs?.toList() ?: emptyList()
                val splitNames = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    appInfo?.splitNames?.toList() ?: emptyList()
                } else {
                    emptyList()
                }
                val nativeDir = appInfo?.nativeLibraryDir ?: ""
                val edition = determineEdition(pkg, versionName)
                val isPreview = edition == MinecraftEdition.PREVIEW
                val matchesTarget = isTargetVersionMatch(versionName)
                val versionCodeValid = isValidVersionCode(versionCode)
                val extractNative = appInfo != null &&
                    (appInfo.flags and ApplicationInfo.FLAG_EXTRACT_NATIVE_LIBS) != 0
                val launchActivity = resolveLaunchActivityName(pm, pkg)
                val targetSdk = appInfo?.targetSdkVersion ?: 0
                val minSdk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    appInfo?.minSdkVersion ?: 0
                } else {
                    0
                }

                val apkQuickScan = quickScanApkNativeSupport(sourceDir, splits, nativeDir)
                val apkHasArm64 = "arm64-v8a" in apkQuickScan.abis ||
                    (nativeDir.isNotBlank() && File(nativeDir, "libminecraftpe.so").exists() && deviceHasArm64)
                val hasArm64 = (deviceAbis.isEmpty() || deviceHasArm64) && apkHasArm64

                val mismatchReason = buildMismatchReason(
                    packageName = pkg,
                    edition = edition,
                    versionName = versionName,
                    versionCode = versionCode,
                    matchesTarget = matchesTarget,
                    versionCodeValid = versionCodeValid,
                    hasArm64 = hasArm64,
                    apkAbis = apkQuickScan.abis,
                    hasMainNativeLib = apkQuickScan.hasArm64MainLib
                )

                val signingSha = computeSigningCertSha256(info)

                val item = InstalledMinecraftPackage(
                    packageName = pkg,
                    appLabel = appLabel,
                    versionName = versionName,
                    versionCode = versionCode,
                    lastUpdateTime = info.lastUpdateTime,
                    sourceDir = sourceDir,
                    splitSourceDirs = splits,
                    splitNames = splitNames,
                    nativeLibraryDir = nativeDir,
                    supportedAbis = deviceAbis,
                    matchesTargetVersion = matchesTarget,
                    isPreviewPackage = isPreview,
                    extractNativeLibs = extractNative,
                    launchActivityName = launchActivity,
                    targetSdkVersion = targetSdk,
                    minSdkVersion = minSdk,
                    edition = edition,
                    apkAbis = apkQuickScan.abis,
                    hasArm64Support = hasArm64,
                    hasMainNativeLib = apkQuickScan.hasArm64MainLib,
                    versionCodeValid = versionCodeValid,
                    signingCertSha256 = signingSha,
                    targetMismatchReason = mismatchReason
                )
                found.add(item)

                val levelMsg = "Found $pkg [${edition.name}] | label='$appLabel' | v$versionName (code=$versionCode) | targetMatch=$matchesTarget | arm64=$hasArm64 (mainLib=${apkQuickScan.hasArm64MainLib}) | splits=${splits.size} | activity=${launchActivity ?: "none"}"
                if (item.isExactTargetReady) {
                    logger?.success("STAGE_A", levelMsg)
                } else {
                    logger?.warn("STAGE_A", "$levelMsg | MISMATCH: ${mismatchReason ?: "not target"}")
                }
            } else {
                logger?.info("STAGE_A", "Package not installed: $pkg")
            }
        }

        return found.sortedWith(
            compareByDescending<InstalledMinecraftPackage> { it.isExactTargetReady }
                .thenByDescending { it.isPreviewPackage && it.matchesTargetVersion }
                .thenByDescending { it.isPreviewPackage }
                .thenByDescending { it.matchesTargetVersion }
                .thenBy { it.packageName }
        )
    }

    fun selectBestPackage(packages: List<InstalledMinecraftPackage>): InstalledMinecraftPackage? {
        if (packages.isEmpty()) return null
        return packages.firstOrNull { it.isExactTargetReady }
            ?: packages.firstOrNull { it.isPreviewPackage && it.matchesTargetVersion }
            ?: packages.firstOrNull { it.matchesTargetVersion && it.versionCodeValid }
            ?: packages.firstOrNull { it.isPreviewPackage }
            ?: packages.first()
    }

    fun determineEdition(packageName: String, versionName: String = ""): MinecraftEdition {
        val pkgLower = packageName.trim().lowercase()
        val verLower = versionName.trim().lowercase()
        return when {
            pkgLower == PREVIEW_PACKAGE_NAME || pkgLower.endsWith(".preview") || pkgLower.contains(".preview.") ->
                MinecraftEdition.PREVIEW
            pkgLower == BETA_PACKAGE_NAME || pkgLower.endsWith(".beta") ->
                MinecraftEdition.BETA
            pkgLower == TRIAL_PACKAGE_NAME || pkgLower.contains("trial") ->
                MinecraftEdition.TRIAL
            pkgLower == RELEASE_PACKAGE_NAME ->
                if ("preview" in verLower) MinecraftEdition.PREVIEW else MinecraftEdition.RELEASE
            "preview" in pkgLower || "preview" in verLower ->
                MinecraftEdition.PREVIEW
            "minecraft" in pkgLower ->
                MinecraftEdition.RELEASE
            else ->
                MinecraftEdition.UNKNOWN
        }
    }

    fun isTargetVersionMatch(versionName: String): Boolean {
        val normalized = versionName.trim()
        if (normalized.isEmpty()) return false
        return TARGET_VERSION_REGEX.containsMatchIn(normalized)
    }

    fun isValidVersionCode(versionCode: Long): Boolean {
        return versionCode > 0L
    }

    fun buildMismatchReason(
        packageName: String,
        edition: MinecraftEdition,
        versionName: String,
        versionCode: Long,
        matchesTarget: Boolean,
        versionCodeValid: Boolean,
        hasArm64: Boolean,
        apkAbis: List<String>,
        hasMainNativeLib: Boolean
    ): String? {
        val issues = mutableListOf<String>()
        if (edition != MinecraftEdition.PREVIEW) {
            issues.add("Edition is ${edition.name} ($packageName), expected Minecraft Preview ($PREVIEW_PACKAGE_NAME)")
        }
        if (!matchesTarget) {
            issues.add("Version $versionName != target $TARGET_VERSION_NAME")
        }
        if (!versionCodeValid) {
            issues.add("Invalid versionCode ($versionCode)")
        }
        if (!hasArm64) {
            issues.add("Missing arm64-v8a support (APKs: ${apkAbis.ifEmpty { listOf("none") }.joinToString(", ")})")
        } else if (!hasMainNativeLib) {
            issues.add("libminecraftpe.so (arm64-v8a) not detected in Base/Split APK or nativeLibraryDir")
        }
        return if (issues.isEmpty()) null else issues.joinToString(" • ")
    }

    private data class ApkNativeQuickScan(
        val abis: List<String>,
        val hasArm64MainLib: Boolean
    )

    private fun quickScanApkNativeSupport(
        sourceDir: String,
        splitSourceDirs: List<String>,
        nativeLibraryDir: String
    ): ApkNativeQuickScan {
        val abis = linkedSetOf<String>()
        var hasArm64Main = false

        if (nativeLibraryDir.isNotBlank()) {
            val nativeMain = File(nativeLibraryDir, "libminecraftpe.so")
            if (nativeMain.exists() && nativeMain.length() > ElfValidator.MIN_MAIN_LIBRARY_BYTES) {
                val check = ElfValidator.validateLibrary(nativeMain, "nativeLibraryDir", requireMinOneMb = true, requireArm64 = true)
                if (check.isAArch64) {
                    abis.add("arm64-v8a")
                    hasArm64Main = true
                }
            }
        }

        val apkPaths = buildList {
            if (sourceDir.isNotBlank()) add(sourceDir)
            addAll(splitSourceDirs.filter { it.isNotBlank() })
        }.distinct()

        for (path in apkPaths) {
            val file = File(path)
            if (!file.exists() || !file.canRead()) continue
            runCatching {
                ZipFile(file).use { zip ->
                    val entries = zip.entries()
                    while (entries.hasMoreElements()) {
                        val entry = entries.nextElement()
                        if (entry.isDirectory) continue
                        val name = entry.name
                        if (name.startsWith("lib/") && name.endsWith(".so")) {
                            val parts = name.split('/')
                            if (parts.size >= 3) {
                                abis.add(parts[1])
                            }
                            if (name == "lib/arm64-v8a/libminecraftpe.so" &&
                                entry.size > ElfValidator.MIN_MAIN_LIBRARY_BYTES
                            ) {
                                hasArm64Main = true
                            }
                        }
                    }
                }
            }
        }
        return ApkNativeQuickScan(abis = abis.toList(), hasArm64MainLib = hasArm64Main)
    }

    private fun queryMinecraftLauncherPackages(pm: PackageManager): List<String> {
        val mainIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolved = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.queryIntentActivities(
                    mainIntent,
                    PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong())
                )
            } else {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(mainIntent, PackageManager.MATCH_ALL)
            }
        }.getOrNull().orEmpty()

        return resolved.mapNotNull { info ->
            val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
            val lower = pkg.lowercase()
            if (lower.contains("minecraft") || lower.contains("mojang")) pkg else null
        }.distinct()
    }

    fun resolveLaunchActivityName(pm: PackageManager, packageName: String): String? {
        val launchIntent = pm.getLaunchIntentForPackage(packageName)
        val fromLaunchIntent = launchIntent?.component?.className
        if (!fromLaunchIntent.isNullOrBlank()) return fromLaunchIntent

        val mainIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            setPackage(packageName)
        }
        val resolved = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.queryIntentActivities(
                    mainIntent,
                    PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_DEFAULT_ONLY.toLong())
                )
            } else {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(mainIntent, PackageManager.MATCH_DEFAULT_ONLY)
            }
        }.getOrNull().orEmpty()
        return resolved.firstOrNull { it.activityInfo?.exported != false }?.activityInfo?.name
            ?: resolved.firstOrNull()?.activityInfo?.name
    }

    fun inspectExternalApk(
        context: Context,
        uri: Uri,
        logger: LeviLogger? = null
    ): ExternalApkInspection {
        val fileName = queryDisplayName(context, uri) ?: "selected.apk"
        val tempApk = File(context.cacheDir, "inspect_external_${System.currentTimeMillis()}.apk")
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempApk).use { out ->
                    input.copyTo(out, 64 * 1024)
                    out.flush()
                }
            } ?: error("Cannot open APK stream")

            val fileSize = tempApk.length()
            val pm = context.packageManager
            val archiveInfo = getPackageArchiveInfoCompat(pm, tempApk.absolutePath)
            val axml = AxmlManifestParser.parseFromApk(tempApk)
            val pkgName = archiveInfo?.packageName ?: axml?.packageName
            val verName = archiveInfo?.versionName ?: axml?.versionName
            val verCode = archiveInfo?.let { PackageInfoCompat.getLongVersionCode(it) } ?: axml?.versionCode
            val edition = if (pkgName != null) {
                determineEdition(pkgName, verName.orEmpty())
            } else {
                MinecraftEdition.UNKNOWN
            }
            val matches = verName != null && isTargetVersionMatch(verName)

            val abis = linkedSetOf<String>()
            var hasArm64Main = false
            var mainLibSize = 0L
            var mainLibValidElf64 = false

            ZipFile(tempApk).use { zip ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    if (entry.isDirectory) continue
                    if (entry.name.startsWith("lib/") && entry.name.endsWith(".so")) {
                        val parts = entry.name.split('/')
                        if (parts.size >= 3) {
                            abis.add(parts[1])
                        }
                        if (entry.name == "lib/arm64-v8a/libminecraftpe.so") {
                            hasArm64Main = true
                            mainLibSize = entry.size
                            val header = ByteArray(20)
                            val read = zip.getInputStream(entry).use { it.read(header) }
                            val check = ElfValidator.validateHeaderBytes(
                                fileName = "libminecraftpe.so",
                                filePath = entry.name,
                                sourceOrigin = fileName,
                                sizeBytes = entry.size,
                                header = header,
                                bytesRead = read,
                                requireMinOneMb = true,
                                requireArm64 = true
                            )
                            mainLibValidElf64 = check.isValid
                        }
                    }
                }
            }

            val isTargetPreview = edition == MinecraftEdition.PREVIEW &&
                matches &&
                (verCode ?: 0L) > 0L &&
                hasArm64Main &&
                mainLibValidElf64

            logger?.info(
                "VERSION_MGR",
                "Inspected external APK $fileName: pkg=$pkgName [${edition.name}], v=$verName ($verCode), targetMatch=$matches, abis=$abis, arm64Main=$hasArm64Main, validElf64=$mainLibValidElf64, perms=${axml?.permissions?.size ?: 0}"
            )

            ExternalApkInspection(
                uriString = uri.toString(),
                fileName = fileName,
                fileSizeBytes = fileSize,
                packageName = pkgName,
                versionName = verName,
                versionCode = verCode,
                edition = edition,
                matchesTargetVersion = matches,
                isTargetPreviewApk = isTargetPreview,
                availableAbis = abis.toList(),
                hasArm64MainLib = hasArm64Main,
                mainLibSizeBytes = mainLibSize,
                mainLibIsValidElf64 = mainLibValidElf64,
                manifestPermissionsCount = axml?.permissions?.size ?: 0
            )
        } catch (t: Throwable) {
            logger?.error("VERSION_MGR", "External APK inspection failed: ${t.message}", t)
            ExternalApkInspection(
                uriString = uri.toString(),
                fileName = fileName,
                fileSizeBytes = 0L,
                packageName = null,
                versionName = null,
                versionCode = null,
                edition = MinecraftEdition.UNKNOWN,
                matchesTargetVersion = false,
                isTargetPreviewApk = false,
                availableAbis = emptyList(),
                hasArm64MainLib = false,
                mainLibSizeBytes = 0L,
                mainLibIsValidElf64 = false,
                errorMessage = "${t.javaClass.simpleName}: ${t.message}"
            )
        } finally {
            tempApk.delete()
        }
    }

    private fun queryDisplayName(context: Context, uri: Uri): String? {
        return runCatching {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        }.getOrNull()
    }

    private fun computeSigningCertSha256(info: PackageInfo): String {
        return runCatching {
            val sigBytes: ByteArray? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val signingInfo = info.signingInfo
                val signers = signingInfo?.apkContentsSigners ?: signingInfo?.signingCertificateHistory
                signers?.firstOrNull()?.toByteArray()
            } else {
                @Suppress("DEPRECATION")
                info.signatures?.firstOrNull()?.toByteArray()
            }
            if (sigBytes == null || sigBytes.isEmpty()) return@runCatching ""
            val digest = MessageDigest.getInstance("SHA-256").digest(sigBytes)
            digest.take(8).joinToString(":") { "%02X".format(it) }
        }.getOrDefault("")
    }

    private fun getPackageInfoCompat(pm: PackageManager, pkg: String): PackageInfo? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val flags = PackageManager.PackageInfoFlags.of(
                    (PackageManager.GET_META_DATA or
                        PackageManager.GET_ACTIVITIES or
                        PackageManager.GET_SIGNING_CERTIFICATES).toLong()
                )
                pm.getPackageInfo(pkg, flags)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(
                    pkg,
                    PackageManager.GET_META_DATA or
                        PackageManager.GET_ACTIVITIES or
                        PackageManager.GET_SIGNING_CERTIFICATES
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(
                    pkg,
                    PackageManager.GET_META_DATA or
                        PackageManager.GET_ACTIVITIES or
                        PackageManager.GET_SIGNATURES
                )
            }
        } catch (_: PackageManager.NameNotFoundException) {
            null
        } catch (_: Throwable) {
            null
        }
    }

    private fun getPackageArchiveInfoCompat(pm: PackageManager, archivePath: String): PackageInfo? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageArchiveInfo(
                    archivePath,
                    PackageManager.PackageInfoFlags.of(PackageManager.GET_META_DATA.toLong())
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageArchiveInfo(archivePath, PackageManager.GET_META_DATA)
            }
        } catch (_: Throwable) {
            null
        }
    }
}
